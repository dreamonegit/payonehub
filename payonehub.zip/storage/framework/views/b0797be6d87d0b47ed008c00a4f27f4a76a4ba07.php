<!DOCTYPE html>
<html lang="en">
<!-- start head Area -->
<?php echo $__env->make('layouts/front/element/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end head Area -->
<body>
<!-- Preloader -->
<div id="preloader"><div data-loader="dual-ring"></div></div><!-- Preloader End -->
	<!-- start header Area -->
    <?php echo $__env->make('layouts/front/element/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- end header Area -->
	
    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- start footer Area -->
	<?php echo $__env->make('layouts/front/element/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <!-- End footer Area -->
	<?php echo $__env->make('layouts/front/element/model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->make('layouts/front/element/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\payonehub\resources\views/layouts/front/default.blade.php ENDPATH**/ ?>