<?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php echo $__env->make('layouts.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Client/</span>Add client</h4>

              <!-- Basic Layout & Basic with Icons -->
              <div class="row">
				<?php if(\Session::has('message')): ?>
					<div class="alert alert-danger">
						<ul>
							<li><?php echo \Session::get('message'); ?></li>
						</ul>
					</div>
				<?php endif; ?>
                <!-- Basic Layout -->
                <div class="col-xxl">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="mb-0"><?php echo e($title); ?></h5>
                    </div>
                    <div class="card-body">
                      <form method="post" action="<?php echo e(url('/admin/addclient')); ?>" id="addclient" enctype='multipart/form-data'><?php echo csrf_field(); ?>
						  <?php if(isset($client)): ?>
							   <input type="hidden" name="id" value="<?php echo e($client->id); ?>"/>
						  <?php endif; ?>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">Name</label>
                          <div class="col-sm-10">
                            <input type="text" name="name" class="form-control" id="name" placeholder="John Doe" value="<?php if(isset($client)): ?> <?php echo e($client->name); ?> <?php endif; ?>"/>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Company</label>
                          <div class="col-sm-10">
                            <input
							  name="company"
                              type="text"
                              class="form-control"
                              id="company"
                              placeholder="ACME Inc."
							  value="<?php if(isset($client)): ?> <?php echo e($client->company); ?> <?php endif; ?>"
                            />
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-email">Email</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                              <input
							    name="email"
                                type="text"
                                id="basic-default-email"
                                class="form-control"
                                placeholder="john.doe"
                                aria-label="john.doe"
                                aria-describedby="basic-default-email2"
								value="<?php if(isset($client)): ?> <?php echo e($client->email); ?> <?php endif; ?>"
                              />
                              <span class="input-group-text" id="basic-default-email2">@example.com</span>
                            </div>
                            <div class="form-text">You can use letters, numbers & periods</div>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-phone">Phone No</label>
                          <div class="col-sm-10">
                            <input
							  name="mobile"
                              type="text"
                              id="mobile"
                              class="form-control phone-mask"
                              placeholder="658 799 8941"
                              aria-label="658 799 8941"
                              aria-describedby="basic-default-phone"
							  value="<?php if(isset($client)): ?> <?php echo e($client->mobile); ?> <?php endif; ?>"
                            />
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Message</label>
                          <div class="col-sm-10">
                            <textarea
							  name="message"
                              id="basic-default-message"
                              class="form-control"
                              placeholder="Hi, Do you have a moment to talk Joe?"
                              aria-label="Hi, Do you have a moment to talk Joe?"
                              aria-describedby="basic-icon-default-message2"
                            ><?php if(isset($client)): ?> <?php echo e($client->message); ?> <?php endif; ?></textarea>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Profile Image</label>
                          <div class="col-sm-10">
								<input class="form-control" type="file" id="formFile" name="profile_image">
                          </div>
                        </div>	
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Role</label>
                          <div class="col-sm-10">
							<select name="role" id="role" class="form-select" name="role">
							  <option>---Default select---</option>
							  <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($roleval->role); ?>" <?php if(isset($client)): ?> <?php if($client->role==$roleval->role): ?> <?php echo e("selected"); ?> <?php endif; ?> <?php endif; ?>><?php echo e($roleval->rolename); ?></option>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
                          </div>
                        </div>					
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Status</label>
                          <div class="col-sm-10">
							<select name="status" id="status" class="form-select">
							  <option>---Default select---</option>
								<option value="0" <?php if(isset($client)): ?> <?php if($client->status==0): ?> <?php echo e("selected"); ?> <?php endif; ?> <?php endif; ?>>Active</option>
								<option value="1" <?php if(isset($client)): ?> <?php if($client->status==1): ?> <?php echo e("selected"); ?> <?php endif; ?> <?php endif; ?>>In-Active</option>
							</select>
                          </div>
                        </div>
                        <div class="row justify-content-end">
                          <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <!-- Basic with Icons -->
              </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
		<?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\payonehub\resources\views/admin/addclient.blade.php ENDPATH**/ ?>