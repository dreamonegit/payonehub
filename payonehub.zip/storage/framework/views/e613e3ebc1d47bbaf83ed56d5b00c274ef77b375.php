<?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

		<?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php echo $__env->make('layouts.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <!--<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">User /</span> User List</h4>-->

              <!-- Basic Bootstrap Table -->
              <!-- Basic Layout -->
              <div class="row">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Add Faqs</h5>
                    </div>
				 <form class="form-horizontal" method="post" id="faqs" enctype="multipart/form-data" action="<?php echo e(Url('admin/save-faqs')); ?>"><?php echo e(csrf_field()); ?>

					<?php if(isset($faqs)): ?>
					<input type="hidden" name="id" value="<?php echo e($faqs->id); ?>">
					<?php else: ?>
					<input type="hidden" name="id" value="0">
					<?php endif; ?>
                    <div class="card-body">
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-fullname">Title</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-fullname2" class="input-group-text"><i class=""></i></span>
                            <input type="text" name="title" class="form-control" id="basic-icon-default-fullname" placeholder="Title"aria-label="John Doe" aria-describedby="basic-icon-default-fullname2" value="<?php if(isset($faqs->title)): ?> <?php echo e($faqs->title); ?> <?php endif; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-fullname">Upload Image</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-image"></i></span>
                            <input type="file"  name="image" class="form-control" id="basic-icon-default-fullname" placeholder="John Doe"aria-label="John Doe" aria-describedby="basic-icon-default-fullname2"/>
                          </div>
                        </div>
                      <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-message">Description</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-message2" class="input-group-text"><i class="bx bx-comment"></i></span>
                            <textarea name="description" id="basic-icon-default-message" class="form-control" placeholder="Enter the Message" aria-label="Hi, Do you have a moment to talk Joe?" aria-describedby="basic-icon-default-message2"><?php if(isset($faqs)): ?> <?php echo e($faqs->description); ?> <?php endif; ?></textarea>
                          </div>
                        </div>
                      <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Status</label>
                        <select class="form-select" name="status" id="status" aria-label="Default select example">
                          <option selected>---choose the status---</option>
                          <option value="0" <?php if(isset($faqs)): ?><?php if($faqs->status==0): ?> <?php echo e("selected"); ?> <?php endif; ?> <?php endif; ?>>Active</option>
                          <option value="1" <?php if(isset($faqs)): ?><?php if($faqs->status==1): ?> <?php echo e("selected"); ?> <?php endif; ?> <?php endif; ?>>In-Active</option>
                        </select>
                      </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
						 <a href="<?php echo e(url('list-faqs')); ?>" class="btn btn-warning">Cancel</a>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
           
 

              <hr class="my-5" />

              <!--/ Responsive Table -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
		<?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\payonehub\resources\views/admin/add-faqs.blade.php ENDPATH**/ ?>